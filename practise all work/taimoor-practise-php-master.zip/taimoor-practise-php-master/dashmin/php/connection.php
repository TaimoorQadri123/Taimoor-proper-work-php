<?php
$server = 'mysql:host=localhost;dbname=p2b_ecom';
$user = 'root';
$password = '';
$pdo = new PDO($server,$user,$password);
?>